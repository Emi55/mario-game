kaboom({
  global: true,
  fullscreen: true,
  scale: 1,
  debug: true,
  clearColor: [0, 0, 0, 1],
});

// drawing out our maps
loadRoot("https://i.imgur.com/");
loadSprite("front-end", "mS73tgO.jpg"); // coin
loadSprite("wordpress", "KPO3fR9.png"); // evil-shroom
loadSprite('block', 'M6rwarW.png');
loadSprite("brick", "7pdNIZJ.png"); // mario
loadSprite("zelda", "I48wr5K.jpg");
loadSprite("mushroom", "0wMd92p.png");
loadSprite("surprise", "gesQ1KP.png");
loadSprite("unboxed", "bdrLpi6.png");
loadSprite("pipe-top-left", "ReTPiWY.png");
loadSprite("pipe-top-right", "hj2GK4n.png");
loadSprite("pipe-bottom-left", "c1cYSbt.png");
loadSprite("pipe-bottom-right", "nqQ79eI.png");

loadSprite("blue-block", "fVscIbn.png");
loadSprite("blue-brick", "3e5YRQd.png");
loadSprite("blue-steel", "gqVoI2b.png");
loadSprite("blue-evil-shroom", "SvV4ueD.png");
loadSprite("blue-surprise", "RMqCc1G.png");


scene("game", () => {
  layers(["bg", "obj", "ui"], "obj")

//   game board
const map = [
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '     %   =*=%=                        ',
    '                                      ',
    '                            -+        ',
    '                    ^   ^   ()        ',
 
 


 '======================================================== ======================================',
]

// assign the sprite
const levelCfg = {
    width: 20,
    height: 20,

    '=': [sprite('block'), solid()],
    '$': [sprite('front-end'), 'front-end'],
    '%': [sprite('surprise'), solid(), 'front-end-surprise'],
    '*': [sprite('surprise'), solid(), 'mushroom-surprise'],
    '}': [sprite('unboxed'), solid()],
    '(': [sprite('pipe-bottom-left'), solid(), scale(0.5)],
    ')': [sprite('pipe-bottom-right'), solid(), scale(0.5)],
    '-': [sprite('pipe-top-left'), solid(), scale(0.5), 'pipe'],
    '+': [sprite('pipe-top-right'), solid(), scale(0.5), 'pipe'],
    '^': [sprite('wordpress'), solid(), 'dangerous'],
    '#': [sprite('mushroom'), solid(), 'mushroom', body()],
    '!': [sprite('blue-block'), solid(), scale(0.5)],
    '£': [sprite('blue-brick'), solid(), scale(0.5)],
    'z': [sprite('blue-evil-shroom'), solid(), scale(0.5), 'dangerous'],
    '@': [sprite('blue-surprise'), solid(), scale(0.5), 'front-end-surprise'],
    'x': [sprite('blue-steel'), solid(), scale(0.5)],

}

//add gane level

const gameLevl = addLevel(map, levelCfg)

// add the score
const scoreLabel = add([
  text('test'),
  pos(30, 6),
  layer('ui'),
  {
    value: 'test',
  }
])

add([
  add([text('level'+' My Skills', pos(4,6))])
])

// GET BIGGER
function big(){
  let timer = 0
  let isBig = false
  return {
    update() {
    if (isBig){
      timer -=dt() 
      if(timer <= 0){
        this.smallify()
      }
    }
    },
    isBig(){
      return isBig
    },
    smallify(){
      this.scale = vec2(1) 
      timer = 0
      isBig = false
    },
    biggify(){
      this.scale = vec2(2) 
      timer = 0
      isBig = true
    }
    
  }

}

const player = add([
  sprite('zelda'), solid(),scale(0.2),
  pos(30, 0),
  body(),
  big(),
  origin('bot')

])


// Grow a mushroom

player

const MOVE_SPEED = 120
const JUMP_FORCE = 360

// MOVE LEFT
keyDown('left', () => {
  player.move(-MOVE_SPEED, 0)
})

// MOVE RIGHT

keyDown('right', () => {
  player.move(MOVE_SPEED, 0)
})

keyPress('space', () =>{
  if (player.grounded()){
    player.jump(JUMP_FORCE)
  }
})

})

start("game");



}